package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.apache.tools.ant.types.Description;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.zerobank.base.TestBase;

public class AccountSummaryPage extends TestBase {
		
	@FindBy(id="account_activity_tab")
	WebElement account_activity_tab;

	@FindBy(id="transfer_funds_tab")
	WebElement transfer_funds_tab;

	@FindBy(id="pay_bills_tab")
	WebElement pay_bills_tab;

	@FindBy(id="money_map_tab")
	WebElement money_map_tab;

	@FindBy(id="online_statements_tab")
	WebElement online_statements_tab;

	@FindBy(id="signin_button")
	WebElement signInBtn;

	@FindBy(id="user_login")
	WebElement uname;

	@FindBy(id="user_password")
	WebElement pwd;

	@FindBy(name="user_remember_me")
	WebElement chkBox;


	@FindBy(name="submit")
	WebElement signBtn;

	@FindBy(id="credentials")
	WebElement questionMArk;

	@FindBy(id="details-button")
	WebElement detailsBtn;

	@FindBy(partialLinkText="Proceed to zero.")
	WebElement proccedtoLink;


	@FindBy(xpath ="//a[contains(text(),'Purchase Foreign Currency')]")
	WebElement Purchase_Foreign_Currency_tab;
	
	@FindBy(xpath="//a[contains(text(),'Transfer Funds')]")
	WebElement transferFund;
	@FindBy(id="tf_amount")
	WebElement amount;
	@FindBy(id="btn_submit")
	WebElement continueBtn;
	@FindBy(id="tf_fromAccountId")
	WebElement dropdown1;
	@FindBy (id="tf_description")
	WebElement Description;
	@FindBy(xpath="//li[3]/a[1]")
	WebElement clickUSrMenu;
	@FindBy(xpath="//a[@id='logout_link']")
	WebElement logOutBtn;




	// @FindBy(xpath ="//a[ text()='Purchase Foreign Currency']")
	//WebElement Purchase_Foreign_Currency_tab;

	@FindBy (id="purchase_cash")
	WebElement purchase_button;




	// constructor
	public AccountSummaryPage() {
	PageFactory.initElements(driver, this);
	}




	// @BeforeMethod

	// assert title
	public void assertAccountSummeryPageTitle() {
	assertEquals(driver.getTitle(), "Zero - Account Summary");
	}



	public LogInPage clickOnSignInButton() {
	signInBtn.click();
	return new LogInPage();
	}

	public AccountSummaryPage logIn() {

	uname.sendKeys(prop.getProperty("userid"));
	pwd.sendKeys(prop.getProperty("password"));
	signBtn.click();
	detailsBtn.click();
	proccedtoLink.click();

	return new AccountSummaryPage();


	}

	public void clickpaybills() {
	pay_bills_tab.click();

	}

	public void clickPurchaseForeignCurrency() {
	Purchase_Foreign_Currency_tab.click();

	}

	public void alertMsg() throws InterruptedException {
	Alert ZbAlert = driver.switchTo().alert();
	String Alert = ZbAlert.getText();
	Thread.sleep(2000);
	System.out.println("The text on Zb alert is = '" + Alert + "'");



	ZbAlert.accept();
	}


	public void firstPositive() throws InterruptedException {
	clickOnSignInButton();
	logIn();
	clickpaybills();

	clickPurchaseForeignCurrency();
	purchase_button.click();


	alertMsg();
	}
	public String getTitle() {
		return driver.getTitle();
		}
	public boolean alertMsgValidation() {
		// return Assert.assertEquals(driver.getTitle(),"Zero - Pay Bills");
		if (("Zero - Pay Bills").equals(getTitle()))
		{
		return true;
		}
		{
		return false;
		}
		}


		public void transferFund() {
		transferFund.click();
		}

		public void selectOne() {
		Select sel= new Select(dropdown1);
		sel.selectByVisibleText("Savings(Avail. balance = $ 1000)");

		}


		public void enteramount() {
		amount.sendKeys(prop.getProperty("amount"));
		}

		public void enterDescription() {
		Description.sendKeys(prop.getProperty("Description"));
		}

		public void clickContinueBtn() {
		continueBtn.click();
		}

		public void clickLogOut() {
		clickUSrMenu.click();
		logOutBtn.click();

		}
		public void fundTransfer()
		{
		clickOnSignInButton();
		logIn();
		transferFund();
		selectOne();
		enteramount();
		enterDescription();
		clickContinueBtn();
		clickLogOut();

		}

		public boolean fundTransferValidation() {
		if (("Zero - Personal Banking - Loans - Credit Cards").equals(getTitle()))
		{
		return true;
		}
		{
		return false;
		}

		}
	
	}
	
	

