package com.qa.zerobank.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.AssertJUnit;
import java.io.IOException;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.PayBills;
import com.qa.zerobank.util.TestUtil;

public class AccountSummaryPageTestCases extends TestBase{
	
	HomePage hp;
	LogInPage lp;
	AccountSummaryPage asp;
	PayBills pb;

	TestUtil testUtil;


	public AccountSummaryPageTestCases() {
	super();
	}

	
	@BeforeMethod
	public void setUp() {
	initialization();
	hp=new HomePage();
	lp=new LogInPage();
	asp= new AccountSummaryPage();
	testUtil=new TestUtil();
	pb= new PayBills();

}

	
	@AfterMethod
	public void tearDown() throws IOException
	{
	TestUtil.takeScreenshotAtTheEndOfTest("LoginPage");
	driver.close();
	driver.quit();
	}

	@Test
	public void verifyAlertMsg() throws InterruptedException {
	asp.firstPositive();
	AssertJUnit.assertEquals(driver.getTitle(),"Zero - Pay Bills");

	}
	@Test
	public void verifyTransferFund() {
	asp.fundTransfer();
	// Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	AssertJUnit.assertTrue(asp.fundTransferValidation());
	}

	}

