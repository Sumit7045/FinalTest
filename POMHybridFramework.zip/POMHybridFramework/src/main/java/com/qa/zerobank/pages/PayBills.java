package com.qa.zerobank.pages;

import com.qa.zerobank.base.TestBase;

public class PayBills extends TestBase {

}
