package com.qa.zerobank.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.DashboardPage;
import com.qa.zerobank.pages.OrangeHRMLoginPage;
import com.qa.zerobank.util.TestUtil;

public class FinalTestCases extends TestBase {
	
	OrangeHRMLoginPage HP;
	TestUtil testUtil;
	DashboardPage DP;
	
	@BeforeMethod
	public void setup1() {
		initialization();
		HP = new OrangeHRMLoginPage();
		DP = new DashboardPage();
		testUtil = new TestUtil();
	}
	
	@AfterMethod
	public void CleanUp() throws IOException {
		TestUtil.takeScreenshotAtTheEndOfTest("OrangeHRMLoginPage");
		// close driver
		driver.close();
		driver.quit();
	}
	
	@Test
	public void Login() {
		HP.finalverify();
		Assert.assertEquals("", false);
	}
	
	
}
