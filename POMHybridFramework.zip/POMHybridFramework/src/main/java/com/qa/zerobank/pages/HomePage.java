package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;

import com.qa.zerobank.base.TestBase;

public class HomePage extends TestBase {
	
	SoftAssert sa;
	
	@FindBy (id="signin_button")
	WebElement signInButton;
	@FindBy (name="searchTerm")
	WebElement SearchBox;
	@FindBy (linkText="Zero Bank")
	WebElement brandLinkZeroBank;
	@FindBy (css="#online-banking")
	WebElement MoreServicesLink;
	@FindBy(className="brand")
	WebElement brandlogo;
	@FindBy(xpath="//div[@class='top_offset']//a[1]")
	WebElement LinkResultPage;
	
	public HomePage () {
		PageFactory.initElements(driver, this);
		
	}
	
	public void AssertHomePageTitle() {
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Home Page");
		
	}
	
	public boolean ValidateBrandLogo() {
		return brandlogo.isDisplayed();
	}
	
	public LogInPage ClickOnSignInButton () {
		signInButton.click();
		return new LogInPage();
	}
	
	public SearchResult enterOnSearchBox(String searchData) {
		SearchBox.click();
		SearchBox.sendKeys(searchData);
		SearchBox.sendKeys(Keys.ENTER);
		return new SearchResult();
		}
	
	public String getTitle() {
		return driver.getTitle();
		}
}

