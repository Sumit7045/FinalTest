package com.qa.zerobank.testcases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.pages.SearchResult;
import com.qa.zerobank.util.TestUtil;

public class HomePageTestCases extends TestBase {
	
	HomePage homePage;
	LogInPage logInPage;
	TestUtil testUtil;
	
	public HomePageTestCases() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialization();
		homePage = new HomePage();
		logInPage = new LogInPage();
		testUtil = new TestUtil();
	}
	
	@AfterMethod
	public void CleanUp() throws IOException {
		TestUtil.takeScreenshotAtTheEndOfTest("HomePage");
		// close driver
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validateHomePage () {
		homePage.AssertHomePageTitle();
	}
	
	@Test
	public void validateLogo() {
		AssertJUnit.assertTrue(homePage.ValidateBrandLogo());
	}
	
	@Test
	public void SignInButtonTest() {
		logInPage = homePage.ClickOnSignInButton();
		logInPage.assertLogInPageTitle();
	}
	
	@Test
	public void executeExe() {
		testUtil.executeExeFile(System.getProperty("user.dir")+ "\\src\\main\\resources\\com\\qa\\zerobank\\seleniumbrowserdrivers\\chromedriver.exe");
	}
	
	 @Test
	    public void dbConnectionTest() throws SQLException, ClassNotFoundException {

	        Connection testcon = testUtil.createDBConnection();
	        ResultSet results = testUtil.executeDBQuery(testcon, "select * from student");

	        //run through each row of result for a column
	        while(results.next()) {
	            String studentname = results.getString("Name");
	            System.out.println("Student name is " + studentname);
	        }

	        testUtil.CloseConnection(testcon);

	    }
	//TESTs
	 	@Test
		public void searchBoxTest() {
		SearchResult SearchResult = homePage.enterOnSearchBox("Online Banking");
		SearchResult.assertSearchResultPageTitle();
		SearchResult.verifySearchResult();
		}
	 	
	 	@Test
	 	public void TestVerifyNeg() {
	 	//hp.verifyTitleNeg();
	 	SoftAssert sa = new SoftAssert();
	 	AssertJUnit.assertEquals( homePage.getTitle(), "Zero - Personal Banking - Loans - Credit Cards1");
	 	sa.assertAll();
	 	}
	 	
		}

