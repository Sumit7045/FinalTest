package com.qa.zerobank.testcases;

import org.testng.annotations.Test;
import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import org.testng.asserts.SoftAssert;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;
import com.qa.zerobank.util.TestUtil;

public class LogInPageTestCases extends TestBase {
	
	HomePage homepage;
	LogInPage logInPage;
	AccountSummaryPage accountSummaryPage;
	TestUtil testUtil;

	public LogInPageTestCases() {
	super();
	}

	@BeforeMethod
	public void beforeMethod()
	{
	initialization();
	homepage = new HomePage();
	logInPage = new LogInPage();
	accountSummaryPage = new AccountSummaryPage();
	testUtil=new TestUtil();
	}

	@AfterMethod
	public void cleanUp() throws IOException
	{
	TestUtil.takeScreenshotAtTheEndOfTest("LogInPage");
	//killDriver();
	driver.close();
	driver.quit();

	}

	@Test
	public void validateLogInPage()
	{
	logInPage=homepage.ClickOnSignInButton();
	logInPage.assertLogInPageTitle();
	}

	@Test
	public void validateLogInFunctionality()
	{
	logInPage=homepage.ClickOnSignInButton();
	accountSummaryPage=logInPage.logIn();
	accountSummaryPage.assertAccountSummeryPageTitle();
	}

	@Test
	public void validateInvalidUsername() throws InterruptedException {
	SoftAssert sa = new SoftAssert();
	logInPage.invalidLogin();
	logInPage.assertLogInPageTitle();
	sa.assertAll();
	}

	@Test
	public void emptyUserAndPass() throws InterruptedException {
	SoftAssert sa = new SoftAssert();
	logInPage.emptyUserPass();
	logInPage.assertLogInPageTitle();
	sa.assertAll();

	}
	
	@Test
	public void verifyforgotpassword() throws InterruptedException {
	SoftAssert sa = new SoftAssert();
	logInPage.forgotPass();
	logInPage.assertLogInPageTitle();
	sa.assertAll();

	}
	
}
	  
	  
	  

