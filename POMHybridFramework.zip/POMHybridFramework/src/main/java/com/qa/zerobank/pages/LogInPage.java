package com.qa.zerobank.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.zerobank.base.TestBase;

public class LogInPage extends TestBase {
	
	// object repository
	@FindBy (id ="signin_button")
	WebElement SignButton;
	
	@FindBy(id="user_login")
	WebElement uname;

	@FindBy(id="user_password")
	WebElement pwd;

	@FindBy(name="user_remember_me")
	WebElement chkBox;


	@FindBy(name="submit")
	WebElement signBtn;

	@FindBy(id="credentials")
	WebElement questionMArk;
	
	@FindBy(id="details-button")
	WebElement detailsBtn;

	@FindBy(partialLinkText="Proceed to zero.")
	WebElement proccedtoLink;
	
	@FindBy(partialLinkText="Forgot your password ?")
	WebElement forgotpassword;
	// Initializing page objects
		public LogInPage() {
			PageFactory.initElements(driver, this);
			
		}
	
	public void assertLogInPageTitle() {
			assertEquals(driver.getTitle(),"Zero - Log in");
			}
	
	public AccountSummaryPage logIn() {
	uname.sendKeys(prop.getProperty("userid"));
	pwd.sendKeys(prop.getProperty("pass"));
	signBtn.click();
	detailsBtn.click();
	proccedtoLink.click();
	return new AccountSummaryPage();
	
	}

	public AccountSummaryPage invalidLogin() throws InterruptedException {
		SignButton.click();
		uname.sendKeys(prop.getProperty("userid1"));
		Thread.sleep(10000);

		pwd.sendKeys(prop.getProperty("password"));
		signBtn.click();
		return new AccountSummaryPage();

		}


		public AccountSummaryPage emptyUserPass() throws InterruptedException {
		SignButton.click();
		uname.sendKeys(prop.getProperty("userid2"));
		Thread.sleep(10000);

		pwd.sendKeys(prop.getProperty("pass2"));
		signBtn.click();
		return new AccountSummaryPage();

		}
		
		public forgotPasswordPage forgotPass() throws InterruptedException {
			SignButton.click();
			forgotpassword.click();
			return new forgotPasswordPage();

			}
}

